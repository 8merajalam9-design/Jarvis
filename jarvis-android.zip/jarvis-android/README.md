# JARVIS for Android (Stage 1)
Native Kotlin, zero third-party libraries. Source compile-checked against the Android SDK.

## Build with no PC
Upload the CONTENTS of this folder to a GitHub repo (include the .github folder), open Actions > Build APK,
download the "jarvis-apk" artifact, unzip, install app-debug.apk.

## First run
AI tab > pick provider > paste key > Save > Test connection.
- OpenRouter (free): key from openrouter.ai/keys, model "openrouter/free" (default), or tap "Refresh free model list".
- Gemini: aistudio.google.com. Claude: console.anthropic.com.
Keys are stored encrypted (Android Keystore), never in the APK.

## Tabs
CORE (orb, voice) | CHAT | VISION | AUTO (routines) | APPS | ACCESS (permissions) | AI (settings) | DATA (memory/history)
