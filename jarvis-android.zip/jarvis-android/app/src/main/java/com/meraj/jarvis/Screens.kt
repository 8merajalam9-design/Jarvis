package com.meraj.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun act(): MainActivity? = J.act

// ============================================================================ CORE (dashboard + voice)
class CoreScreen(c: Context) : Screen(c) {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var tasksBox: LinearLayout
    private lateinit var scroll: ScrollView

    override fun build(): View {
        val v = ctx.vbox(12)
        status = ctx.label("", 13f, C.DIM).apply { gravity = Gravity.CENTER }
        val orb = OrbView(ctx).apply { setOnClickListener { Brain.tapOrb() } }
        v.add(orb, 0, h = 0, weight = 1.6f)
        v.add(status, 2)
        transcript = ctx.label("", 15f)
        scroll = ctx.scroll(transcript.apply { setPadding(8.dp(), 8.dp(), 8.dp(), 8.dp()) })
        v.add(scroll, 6, h = 0, weight = 1f)
        tasksBox = ctx.vbox()
        v.add(tasksBox, 6)
        val input = ctx.field("Type a command…").apply { setSingleLine(true) }
        val send = ctx.btn("Send") { val t = input.text.toString(); input.setText(""); Brain.submit(t) }
        val mic = ctx.btn("🎤", C.GREEN) { Brain.tapOrb() }
        val row = ctx.hbox()
        row.add(input, w = 0, weight = 1f)
        row.add(send)
        row.add(mic)
        v.add(row, 8)
        v.add(ctx.sw("Wake word: say “Hey Jarvis” (while app is open)", S.wakeWord) { S.wakeWord = it; if (it) Brain.startWake() else Brain.stopWake() }, 6)
        v.add(ctx.sw("Hands-free: keep listening after replies", S.handsFree) { S.handsFree = it }, 2)
        refresh()
        return v
    }

    override fun refresh() {
        if (!::status.isInitialized) return
        status.text = when (Brain.state) {
            St.IDLE -> if (Brain.wakeLoop) "Wake word armed. Say “Hey Jarvis”, or tap the orb." else "Tap the orb to talk"
            St.LISTENING -> "Listening…"
            St.THINKING -> "Thinking… (tap to cancel)"
            St.SPEAKING -> "Speaking (tap to interrupt)"
        }
        val last = Brain.lines.takeLast(4)
        val sb = StringBuilder()
        for (l in last) sb.append(when (l.role) { "user" -> "You: "; "jarvis" -> "JARVIS: "; else -> "" }).append(l.text).append("\n\n")
        if (Brain.partial.isNotBlank()) sb.append("You: ").append(Brain.partial).append("…")
        transcript.text = sb.toString().trim()
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        tasksBox.removeAllViews()
        val active = Tasks.list.filter { it.status == "running" }
        if (active.isNotEmpty()) {
            tasksBox.header("AI ACTIVITY")
            for (t in active) {
                val row = ctx.card()
                row.add(ctx.label("#${t.id} ${t.title}", 13f))
                row.add(ctx.label(t.step, 12f, C.AMBER), 2)
                row.add(ctx.btn("Cancel", C.RED) { Tasks.cancel(t.id) }, 6)
                tasksBox.add(row, 4)
            }
        }
    }
}

// ============================================================================ CHAT
class ChatScreen(c: Context) : Screen(c) {
    private lateinit var list: LinearLayout
    private lateinit var sv: ScrollView

    override fun build(): View {
        val v = ctx.vbox(12)
        list = ctx.vbox()
        sv = ctx.scroll(list)
        v.add(sv, 0, h = 0, weight = 1f)
        val input = ctx.field("Message JARVIS…").apply { setSingleLine(true) }
        val send = ctx.btn("Send") { val t = input.text.toString(); input.setText(""); Brain.submit(t, speak = false) }
        val attach = ctx.btn("📎") {
            act()?.pick("*/*") { uri -> act()?.analyzeFile(uri) }
        }
        val row = ctx.hbox()
        row.add(attach)
        row.add(input, w = 0, weight = 1f)
        row.add(send)
        v.add(row, 8)
        refresh()
        return v
    }

    override fun refresh() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        for (l in Brain.lines) {
            val mine = l.role == "user"
            val col = when (l.role) { "user" -> C.BLUE; "jarvis" -> C.CYAN; else -> C.DIM }
            val b = ctx.label(l.text, 15f).apply {
                background = rounded(Color.argb(35, Color.red(col), Color.green(col), Color.blue(col)), col)
                setPadding(12.dp(), 8.dp(), 12.dp(), 8.dp())
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = 6.dp(); lp.gravity = if (mine) Gravity.END else Gravity.START
            lp.leftMargin = if (mine) 40.dp() else 0; lp.rightMargin = if (mine) 0 else 40.dp()
            list.addView(b, lp)
        }
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }
}

// ============================================================================ VISION
class VisionScreen(c: Context) : Screen(c) {
    private lateinit var state: TextView
    private lateinit var out: TextView

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("JARVIS VISION", 18f, C.CYAN, true))
        v.add(ctx.label("Share your screen with JARVIS. Frames stay in memory, are captured only during a session you start, and are sent to your chosen AI provider only when you ask a question about the screen.", 13f, C.DIM), 4)
        state = ctx.label("", 15f, C.TEXT, true)
        v.add(ctx.card().apply { add(state) }, 10)
        val row = ctx.hbox()
        row.add(ctx.btn("Start sharing", C.GREEN) { act()?.requestProjection() })
        row.add(ctx.btn("Stop", C.RED) { ScreenCap.stop() }, 0)
        v.add(row, 10)
        val row2 = ctx.hbox()
        row2.add(ctx.btn("What am I looking at?") { ask("What am I looking at on my screen? Explain briefly.") })
        row2.add(ctx.btn("Read text") { ask("Extract and read the visible text on my screen.") })
        v.add(row2, 8)
        val row3 = ctx.hbox()
        row3.add(ctx.btn("Summarize") { ask("Summarize what is on my screen.") })
        row3.add(ctx.btn("Search more") { ask("Look at my screen and search the internet for more information about it.") })
        v.add(row3, 8)
        v.add(ctx.btn("Analyze a screenshot / image…") { act()?.pick("image/*") { uri -> act()?.analyzeFile(uri) } }, 8)
        v.header("LAST ANSWER")
        out = ctx.label("", 15f)
        v.add(out, 4)
        refresh()
        return ctx.scroll(v)
    }

    private fun ask(q: String) { act()?.show(0); Brain.submit(q) }

    override fun refresh() {
        if (!::state.isInitialized) return
        state.text = if (ScreenCap.active) "● SHARING ACTIVE" else "○ Not sharing"
        state.setTextColor(if (ScreenCap.active) C.RED else C.DIM)
        out.text = Brain.lines.lastOrNull { it.role == "jarvis" }?.text ?: ""
    }
}

// ============================================================================ AUTOMATION
class AutoScreen(c: Context) : Screen(c) {
    private lateinit var box: LinearLayout

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("AUTOMATION", 18f, C.CYAN, true))
        v.add(ctx.label("A routine is a plan in plain words. JARVIS carries it out with its tools. Anything that sends a message still asks you to confirm.", 13f, C.DIM), 4)
        box = ctx.vbox()
        v.add(box, 8)
        v.header("NEW ROUTINE")
        val name = ctx.field("Name, e.g. Study mode")
        val ins = ctx.field("What should it do? e.g. Suggest Do Not Disturb, open Chrome, start a 25 minute timer")
        v.add(name, 6); v.add(ins, 6)
        v.add(ctx.btn("Save routine") {
            if (name.text.isNotBlank() && ins.text.isNotBlank()) {
                DB.routines.add(JSONObject().put("name", name.text.toString().trim()).put("instructions", ins.text.toString().trim()))
                name.setText(""); ins.setText(""); Bus.emit()
            }
        }, 6)
        v.header("PRESETS")
        v.add(ctx.btn("Add “Study mode”") {
            DB.routines.add(JSONObject().put("name", "Study mode").put("instructions", "Open Do Not Disturb settings so I can enable it, start a 25 minute timer labelled Study, and open Chrome.")); Bus.emit()
        }, 4)
        v.add(ctx.btn("Add “Good night”") {
            DB.routines.add(JSONObject().put("name", "Good night").put("instructions", "Tell me tomorrow's weather, set brightness to 10 percent, and turn the flashlight off.")); Bus.emit()
        }, 4)
        refresh()
        return ctx.scroll(v)
    }

    override fun refresh() {
        if (!::box.isInitialized) return
        box.removeAllViews()
        val rs = DB.routines.all()
        if (rs.isEmpty()) box.add(ctx.label("No routines yet.", 13f, C.DIM))
        for (r in rs) {
            val card = ctx.card()
            card.add(ctx.label(r.optString("name"), 16f, C.TEXT, true))
            card.add(ctx.label(r.optString("instructions"), 13f, C.DIM), 2)
            val row = ctx.hbox()
            row.add(ctx.btn("Run", C.GREEN) { act()?.show(0); Brain.submit("Run my routine '${r.optString("name")}': ${r.optString("instructions")}") })
            row.add(ctx.btn("Delete", C.RED) { DB.routines.remove(r.optLong("id")); Bus.emit() })
            card.add(row, 6)
            box.add(card, 6)
        }
    }
}

// ============================================================================ APPS
class AppsScreen(c: Context) : Screen(c) {
    private lateinit var list: LinearLayout
    private var apps: List<Pair<String, String>> = emptyList()
    private lateinit var q: EditText

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("APP CONTROL", 18f, C.CYAN, true))
        v.header("SYSTEM BUTTONS (needs Accessibility)")
        val r1 = ctx.hbox()
        for ((n, a) in listOf("Back" to "back", "Home" to "home", "Recents" to "recents", "Shot" to "screenshot"))
            r1.add(ctx.btn(n) { toast(JarvisAccessibility.act(a)) })
        v.add(r1, 4)
        v.header("QUICK SETTINGS")
        val pages = listOf("Wi-Fi" to "wifi", "Bluetooth" to "bluetooth", "Display" to "display", "Sound" to "sound",
            "Battery" to "battery", "Location" to "location", "DND" to "dnd", "Airplane" to "airplane")
        for (chunk in pages.chunked(3)) {
            val row = ctx.hbox()
            for ((n, p) in chunk) row.add(ctx.btn(n) { Tools.openSettings(p) })
            v.add(row, 4)
        }
        v.header("INSTALLED APPS")
        q = ctx.field("Search apps…").apply {
            setSingleLine(true)
            addTextChangedListener(object : android.text.TextWatcher {
                override fun afterTextChanged(s: android.text.Editable?) { render() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        v.add(q, 4)
        list = ctx.vbox()
        v.add(list, 6)
        Thread { apps = Tools.launchables(); J.main.post { render() } }.start()
        return ctx.scroll(v)
    }

    private fun toast(s: String) = J.onMain { Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show() }

    private fun render() {
        list.removeAllViews()
        val f = q.text.toString().lowercase()
        for ((name, _) in apps.filter { it.first.lowercase().contains(f) }.take(40)) {
            val row = ctx.hbox()
            row.add(ctx.label(name, 15f), w = 0, weight = 1f)
            row.add(ctx.btn("Open") { Tools.openApp(name) })
            list.add(row, 4)
        }
    }
}

// ============================================================================ PERMISSIONS
class PermScreen(c: Context) : Screen(c) {
    private lateinit var box: LinearLayout

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("PERMISSIONS", 18f, C.CYAN, true))
        v.add(ctx.label("JARVIS never turns these on by itself. Each one is optional and can be revoked in Android settings at any time.", 13f, C.DIM), 4)
        box = ctx.vbox()
        v.add(box, 8)
        refresh()
        return ctx.scroll(v)
    }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun row(title: String, why: String, on: Boolean, grant: () -> Unit) {
        val card = ctx.card()
        val top = ctx.hbox()
        top.add(ctx.label(title, 15f, C.TEXT, true), w = 0, weight = 1f)
        top.add(ctx.label(if (on) "ON" else "OFF", 13f, if (on) C.GREEN else C.AMBER, true))
        card.add(top)
        card.add(ctx.label(why, 12f, C.DIM), 2)
        if (!on) card.add(ctx.btn("Grant") { grant() }, 6)
        box.add(card, 6)
    }

    private fun runtime(p: String) { act()?.requestPermissions(arrayOf(p), 1) }
    private fun open(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    override fun refresh() {
        if (!::box.isInitialized) return
        box.removeAllViews()
        row("Microphone", "Voice commands and wake word.", has(Manifest.permission.RECORD_AUDIO)) { runtime(Manifest.permission.RECORD_AUDIO) }
        row("Contacts", "Find people by name for messages and calls.", has(Manifest.permission.READ_CONTACTS)) { runtime(Manifest.permission.READ_CONTACTS) }
        row("Send SMS", "Send texts after you confirm. Without it, your SMS app opens with the message ready.", has(Manifest.permission.SEND_SMS)) { runtime(Manifest.permission.SEND_SMS) }
        if (android.os.Build.VERSION.SDK_INT >= 33)
            row("Notifications", "Show task results, reminders and the screen-sharing indicator.", has(Manifest.permission.POST_NOTIFICATIONS)) { runtime(Manifest.permission.POST_NOTIFICATIONS) }
        row("Notification access", "Lets JARVIS read incoming notifications so you can ask about them.", Tools.notifAccessEnabled()) { open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        row("Accessibility service", "Back/Home/Recents/Screenshot and reading on-screen text. You enable it yourself in Android settings.", Tools.a11yEnabled()) { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        row("Modify system settings", "Needed only to change screen brightness.", Settings.System.canWrite(ctx)) { open(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
        row("Screen capture", "Asked each time you start JARVIS Vision. Nothing is captured otherwise.", ScreenCap.active) { act()?.requestProjection() }
    }
}

// ============================================================================ AI SETTINGS
class SettingsScreen(c: Context) : Screen(c) {
    private lateinit var provBox: LinearLayout
    private lateinit var keyBox: LinearLayout
    private lateinit var free: LinearLayout
    private lateinit var testOut: TextView

    private val provs = listOf("gemini" to "Gemini", "openrouter" to "OpenRouter (free)", "claude" to "Claude")

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("AI SETTINGS", 18f, C.CYAN, true))
        v.add(ctx.label("Keys are typed here, stored encrypted with the Android Keystore, and never built into the app.", 13f, C.DIM), 4)
        v.header("PROVIDER")
        provBox = ctx.hbox()
        v.add(provBox, 6)
        keyBox = ctx.vbox()
        v.add(keyBox, 8)
        free = ctx.vbox()
        v.add(free, 4)
        v.add(ctx.btn("Test connection") {
            testOut.text = "Testing…"
            Thread {
                val r = try { AI.once("Reply with exactly: Online.", "ping") } catch (e: Exception) { "Failed: ${e.message}" }
                J.main.post { testOut.text = r }
            }.start()
        }, 10)
        testOut = ctx.label("", 13f, C.GREEN)
        v.add(testOut, 4)

        v.header("VOICE")
        v.add(ctx.label("Speaking speed", 13f, C.DIM), 4)
        v.add(seek((S.ttsSpeed * 50).toInt() - 15, 100) { S.ttsSpeed = (it + 15) / 50f }, 2)
        v.add(ctx.label("Voice pitch", 13f, C.DIM), 4)
        v.add(seek((S.ttsPitch * 50).toInt() - 15, 100) { S.ttsPitch = (it + 15) / 50f }, 2)
        v.add(ctx.label("Speech recognition language", 13f, C.DIM), 6)
        val lr = ctx.hbox()
        for ((n, c2) in listOf("Auto" to "system", "English (IN)" to "en-IN", "हिन्दी / Hinglish" to "hi-IN"))
            lr.add(ctx.btn(n) { S.speechLang = c2; Toast.makeText(ctx, "Language: $n", Toast.LENGTH_SHORT).show() })
        v.add(lr, 4)
        v.add(ctx.sw("Speak replies aloud", S.speakReplies) { S.speakReplies = it }, 8)

        v.header("PRIVACY & MEMORY")
        v.add(ctx.sw("Use personal memory in conversations", S.memoryOn) { S.memoryOn = it }, 4)
        v.add(ctx.sw("Allow clipboard assist (JARVIS may read the clipboard when asked)", S.clipboardOn) { S.clipboardOn = it }, 4)
        v.add(ctx.label("Default country code for 10-digit numbers", 13f, C.DIM), 8)
        val cc = ctx.field("91").apply { setText(S.countryCode); setSingleLine(true) }
        v.add(cc, 4)
        v.add(ctx.btn("Save country code") { S.countryCode = cc.text.toString() }, 4)
        refreshAll()
        return ctx.scroll(v)
    }

    private fun seek(progress: Int, max: Int, change: (Int) -> Unit) = SeekBar(ctx).apply {
        this.max = max; this.progress = progress.coerceIn(0, max)
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) change(p) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun refreshAll() {
        provBox.removeAllViews()
        for ((id, n) in provs) provBox.add(ctx.btn(n, if (S.provider == id) C.GREEN else C.DIM) { S.provider = id; refreshAll() })
        keyBox.removeAllViews()
        val prov = S.provider
        val name = provs.first { it.first == prov }.second
        val keyHint = when (prov) {
            "gemini" -> "Gemini API key (aistudio.google.com)"
            "openrouter" -> "OpenRouter API key (openrouter.ai/keys)"
            else -> "Anthropic API key (console.anthropic.com)"
        }
        keyBox.add(ctx.label("$name key ${if (S.key(prov).isNotBlank()) "(saved ✓)" else "(not set)"}", 13f, C.DIM))
        val key = ctx.field(keyHint, true)
        keyBox.add(key, 4)
        val model = ctx.field("Model").apply { setText(S.model(prov)); setSingleLine(true) }
        keyBox.add(ctx.label("Model", 13f, C.DIM), 8)
        keyBox.add(model, 4)
        keyBox.add(ctx.btn("Save") {
            if (key.text.isNotBlank()) S.setKey(prov, key.text.toString())
            S.setModel(prov, model.text.toString())
            Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show(); refreshAll()
        }, 8)
        free.removeAllViews()
        if (prov == "openrouter") {
            free.header("FREE MODELS")
            free.add(ctx.label("openrouter/free picks a working free model automatically. Free models rotate often; tap Refresh for the current list.", 12f, C.DIM), 2)
            free.add(ctx.btn("Use openrouter/free") { S.setModel("openrouter", "openrouter/free"); refreshAll() }, 6)
            free.add(ctx.btn("Refresh free model list") { loadFree() }, 6)
        }
    }

    private fun loadFree() {
        Thread {
            try {
                val r = Net.http("GET", "https://openrouter.ai/api/v1/models", timeout = 20000)
                val arr = JSONObject(r.body).getJSONArray("data")
                val ids = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val pr = m.optJSONObject("pricing")
                    if (pr != null && pr.optString("prompt") == "0" && pr.optString("completion") == "0") {
                        val params = m.optJSONArray("supported_parameters")
                        val tools = params != null && params.toString().contains("tools")
                        ids.add((if (tools) "★ " else "") + m.getString("id"))
                    }
                }
                ids.sortByDescending { it.startsWith("★") }
                J.main.post {
                    free.header("TAP TO USE (★ = supports tools)")
                    for (id in ids.take(25)) free.add(ctx.btn(id) { S.setModel("openrouter", id.removePrefix("★ ")); refreshAll() }, 4)
                }
            } catch (e: Exception) { J.main.post { Toast.makeText(ctx, "Could not load: ${e.message}", Toast.LENGTH_LONG).show() } }
        }.start()
    }
}

// ============================================================================ HISTORY & DATA
class HistoryScreen(c: Context) : Screen(c) {
    private lateinit var box: LinearLayout

    override fun build(): View {
        val v = ctx.vbox(12)
        v.add(ctx.label("HISTORY & DATA", 18f, C.CYAN, true))
        v.add(ctx.label("Everything here is stored encrypted on this phone only. You can delete any of it.", 13f, C.DIM), 4)
        box = ctx.vbox()
        v.add(box, 8)
        refresh()
        return ctx.scroll(v)
    }

    private fun section(title: String, store: Store, clearLabel: String, fmt: (JSONObject) -> String) {
        box.header(title)
        val items = store.all()
        if (items.isEmpty()) box.add(ctx.label("Empty.", 13f, C.DIM), 4)
        for (o in items.takeLast(25).reversed()) {
            val row = ctx.hbox()
            row.add(ctx.label(fmt(o), 13f), w = 0, weight = 1f)
            row.add(ctx.btn("✕", C.RED) { store.remove(o.optLong("id")); Bus.emit() })
            box.add(row, 4)
        }
        if (items.isNotEmpty()) box.add(ctx.btn(clearLabel, C.RED) { store.clear(); Bus.emit() }, 6)
    }

    override fun refresh() {
        if (!::box.isInitialized) return
        box.removeAllViews()
        val df = SimpleDateFormat("d MMM HH:mm", Locale.getDefault())
        section("MEMORY (what JARVIS knows about you)", DB.memory, "Clear memory") { it.optString("text") }
        section("TO-DO", DB.todos, "Clear to-dos") { (if (it.optBoolean("done")) "✔ " else "○ ") + it.optString("text") }
        section("NOTES", DB.notes, "Clear notes") { it.optString("text") }
        section("CONVERSATION HISTORY", DB.history, "Delete conversation history") {
            df.format(Date(it.optLong("time"))) + "  " + (if (it.optString("role") == "user") "You: " else "JARVIS: ") + it.optString("text").take(200)
        }
        box.add(ctx.btn("New conversation (forget this session's context)") { Brain.convo.clear(); Brain.lines.clear(); Bus.emit() }, 10)
    }
}
