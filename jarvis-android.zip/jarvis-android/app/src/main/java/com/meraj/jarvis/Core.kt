package com.meraj.jarvis

import android.app.Application
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class JarvisApp : Application() {
    override fun onCreate() { super.onCreate(); J.app = this }
}

object J {
    lateinit var app: Application
    val main = Handler(Looper.getMainLooper())
    @Volatile var act: MainActivity? = null

    fun onMain(b: () -> Unit) { if (Looper.myLooper() == Looper.getMainLooper()) b() else main.post(b) }

    fun <T> onMainWait(b: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return b()
        val ref = AtomicReference<T>()
        val latch = CountDownLatch(1)
        main.post { try { ref.set(b()) } finally { latch.countDown() } }
        latch.await(4, TimeUnit.SECONDS)
        return ref.get()
    }
}

/** Tiny pub/sub so screens can refresh when anything changes. */
object Bus {
    private val subs = CopyOnWriteArrayList<() -> Unit>()
    fun clear() = subs.clear()
    fun sub(f: () -> Unit) { subs.add(f) }
    fun emit() { J.main.post { subs.forEach { it() } } }
}
