package com.meraj.jarvis

import android.text.Html
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

object Net {
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    class Resp(val code: Int, val body: String)

    fun http(method: String, url: String, headers: Map<String, String> = emptyMap(), body: String? = null, timeout: Int = 60000): Resp {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 15000
        c.readTimeout = timeout
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", UA)
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        if (body != null) { c.doOutput = true; c.outputStream.use { it.write(body.toByteArray()) } }
        val code = c.responseCode
        val stream = if (code in 200..399) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Resp(code, text)
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun errMsg(body: String): String = try {
        val e = JSONObject(body).opt("error")
        when (e) {
            is JSONObject -> e.optString("message", body.take(160))
            is String -> e
            else -> body.take(160)
        }
    } catch (ex: Exception) { body.take(160) }

    fun strip(html: String): String {
        val noScript = html.replace(Regex("(?is)<(script|style|noscript|svg)[^>]*>.*?</\\1>"), " ")
        val noTags = noScript.replace(Regex("(?s)<[^>]+>"), " ")
        return Html.fromHtml(noTags, Html.FROM_HTML_MODE_LEGACY).toString().replace(Regex("\\s+"), " ").trim()
    }

    // ------------------------------------------------------------ web search
    fun search(q: String): String {
        val gem = S.key("gemini")
        if (gem.isNotBlank()) {
            try { return groundedSearch(q, gem) } catch (e: Exception) { /* fall through to scraping */ }
        }
        try { val r = ddg(q); if (r.isNotBlank()) return r } catch (e: Exception) { }
        return try { bing(q).ifBlank { "No results found." } } catch (e: Exception) { "Search failed: ${e.message}" }
    }

    private fun groundedSearch(q: String, key: String): String {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", q)))))
            .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text",
                "Answer with current, factual information in under 180 words. Include concrete numbers, names and dates."))))
        val r = http("POST", "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
            mapOf("Content-Type" to "application/json", "x-goog-api-key" to key), body.toString())
        if (r.code !in 200..299) throw Exception(errMsg(r.body))
        val cand = JSONObject(r.body).getJSONArray("candidates").getJSONObject(0)
        val parts = cand.getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        val chunks = cand.optJSONObject("groundingMetadata")?.optJSONArray("groundingChunks")
        if (chunks != null && chunks.length() > 0) {
            sb.append("\nSources:")
            for (i in 0 until minOf(3, chunks.length())) {
                val w = chunks.getJSONObject(i).optJSONObject("web") ?: continue
                sb.append("\n- ").append(w.optString("title")).append(" ").append(w.optString("uri"))
            }
        }
        return sb.toString().trim()
    }

    private fun ddg(q: String): String {
        val r = http("GET", "https://html.duckduckgo.com/html/?q=${enc(q)}", timeout = 20000)
        val re = Regex("(?s)<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>.*?class=\"result__snippet\"[^>]*>(.*?)</a>")
        val sb = StringBuilder()
        var n = 0
        for (m in re.findAll(r.body)) {
            var href = m.groupValues[1]
            if (href.contains("uddg=")) href = URLDecoder.decode(href.substringAfter("uddg=").substringBefore("&"), "UTF-8")
            sb.append("${++n}. ${strip(m.groupValues[2])}\n   $href\n   ${strip(m.groupValues[3])}\n")
            if (n >= 6) break
        }
        return sb.toString()
    }

    private fun bing(q: String): String {
        val r = http("GET", "https://www.bing.com/search?q=${enc(q)}", timeout = 20000)
        val re = Regex("(?s)<li class=\"b_algo\".*?<h2><a href=\"([^\"]+)\"[^>]*>(.*?)</a></h2>.*?<p[^>]*>(.*?)</p>")
        val sb = StringBuilder()
        var n = 0
        for (m in re.findAll(r.body)) {
            sb.append("${++n}. ${strip(m.groupValues[2])}\n   ${m.groupValues[1]}\n   ${strip(m.groupValues[3])}\n")
            if (n >= 6) break
        }
        return sb.toString()
    }

    fun readPage(url: String): String {
        val r = http("GET", url, timeout = 25000)
        if (r.code !in 200..299) return "Could not load page (HTTP ${r.code})."
        return strip(r.body).take(7000).ifBlank { "The page had no readable text." }
    }

    // ------------------------------------------------------------ weather / news / speed
    fun weather(place: String): String {
        val r = http("GET", "https://wttr.in/${enc(place.trim())}?format=j1", timeout = 20000)
        if (r.code !in 200..299) return "Weather lookup failed (HTTP ${r.code})."
        val o = JSONObject(r.body)
        val cur = o.getJSONArray("current_condition").getJSONObject(0)
        val area = o.optJSONArray("nearest_area")?.optJSONObject(0)?.optJSONArray("areaName")?.optJSONObject(0)?.optString("value") ?: place
        val sb = StringBuilder("Weather in $area: ${cur.getJSONArray("weatherDesc").getJSONObject(0).getString("value")}, ")
        sb.append("${cur.getString("temp_C")}°C (feels ${cur.getString("FeelsLikeC")}°C), humidity ${cur.getString("humidity")}%, wind ${cur.getString("windspeedKmph")} km/h.")
        val days = o.optJSONArray("weather")
        if (days != null) for (i in 0 until minOf(3, days.length())) {
            val d = days.getJSONObject(i)
            sb.append("\n${d.getString("date")}: ${d.getString("mintempC")}–${d.getString("maxtempC")}°C")
        }
        return sb.toString()
    }

    fun news(topic: String): String {
        val url = if (topic.isBlank()) "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en"
        else "https://news.google.com/rss/search?q=${enc(topic)}&hl=en-IN&gl=IN&ceid=IN:en"
        val r = http("GET", url, timeout = 20000)
        if (r.code !in 200..299) return "News lookup failed (HTTP ${r.code})."
        val re = Regex("(?s)<item>.*?<title>(.*?)</title>")
        val items = re.findAll(r.body).map { strip(it.groupValues[1].replace("<![CDATA[", "").replace("]]>", "")) }.take(8).toList()
        return if (items.isEmpty()) "No news found." else items.mapIndexed { i, t -> "${i + 1}. $t" }.joinToString("\n")
    }

    fun speedTest(): String {
        val t0 = System.nanoTime()
        var total = 0L
        val c = URL("https://speed.cloudflare.com/__down?bytes=20000000").openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 15000
        c.inputStream.use { s ->
            val buf = ByteArray(65536)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                total += n
                if (System.nanoTime() - t0 > 8_000_000_000L) break
            }
        }
        val sec = (System.nanoTime() - t0) / 1e9
        val mbps = total * 8 / 1e6 / sec
        return "Download speed about %.1f Mbps (%.1f MB in %.1f s).".format(mbps, total / 1e6, sec)
    }

    fun b64(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)
}
