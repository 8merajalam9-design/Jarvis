package com.meraj.jarvis

import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ToolCall(val id: String, val name: String, val args: JSONObject)

class Msg(
    val role: String, // user | assistant | tool
    val text: String = "",
    val calls: List<ToolCall> = emptyList(),
    val results: List<Pair<ToolCall, String>> = emptyList(),
    val image: String? = null
)

class P(val name: String, val type: String, val desc: String, val required: Boolean = true)
class Spec(val name: String, val desc: String, val params: List<P>)

/** One interface over Gemini, OpenRouter (free models) and Claude, with tool calling. */
object AI {
    private val textToolModels = HashSet<String>()

    fun chat(system: String, msgs: List<Msg>, specs: List<Spec>): Msg = when (S.provider) {
        "gemini" -> gemini(system, msgs, specs)
        "claude" -> claude(system, msgs, specs)
        else -> openrouter(system, msgs, specs)
    }

    fun once(system: String, text: String, image: String? = null): String =
        chat(system, listOf(Msg("user", text, image = image)), emptyList()).text.trim()

    private fun props(s: Spec, upper: Boolean): JSONObject {
        val p = JSONObject()
        for (x in s.params) p.put(x.name, JSONObject().put("type", if (upper) x.type.uppercase() else x.type).put("description", x.desc))
        return p
    }
    private fun req(s: Spec) = JSONArray(s.params.filter { it.required }.map { it.name })

    private fun need(prov: String, label: String): String {
        val k = S.key(prov)
        if (k.isBlank()) throw Exception("Add your $label API key in the AI tab first.")
        return k
    }

    // ------------------------------------------------------------------ Gemini
    private fun gemini(system: String, msgs: List<Msg>, specs: List<Spec>): Msg {
        val key = need("gemini", "Gemini")
        val model = S.model("gemini")
        val contents = JSONArray()
        for (m in msgs) when (m.role) {
            "user" -> {
                val parts = JSONArray().put(JSONObject().put("text", m.text.ifBlank { " " }))
                if (m.image != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", m.image)))
                contents.put(JSONObject().put("role", "user").put("parts", parts))
            }
            "assistant" -> {
                val parts = JSONArray()
                if (m.text.isNotBlank()) parts.put(JSONObject().put("text", m.text))
                for (c in m.calls) parts.put(JSONObject().put("functionCall", JSONObject().put("name", c.name).put("args", c.args)))
                if (parts.length() == 0) parts.put(JSONObject().put("text", " "))
                contents.put(JSONObject().put("role", "model").put("parts", parts))
            }
            "tool" -> {
                val parts = JSONArray()
                for ((c, r) in m.results) parts.put(JSONObject().put("functionResponse",
                    JSONObject().put("name", c.name).put("response", JSONObject().put("result", r))))
                contents.put(JSONObject().put("role", "user").put("parts", parts))
            }
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
        if (specs.isNotEmpty()) {
            val decls = JSONArray()
            for (s in specs) {
                val d = JSONObject().put("name", s.name).put("description", s.desc)
                if (s.params.isNotEmpty()) d.put("parameters", JSONObject().put("type", "OBJECT").put("properties", props(s, true)).put("required", req(s)))
                decls.put(d)
            }
            body.put("tools", JSONArray().put(JSONObject().put("function_declarations", decls)))
        }
        if (model.contains("2.5") && model.contains("flash"))
            body.put("generationConfig", JSONObject().put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
        val r = Net.http("POST", "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
            mapOf("Content-Type" to "application/json", "x-goog-api-key" to key), body.toString())
        if (r.code !in 200..299) throw Exception("Gemini ${r.code}: ${Net.errMsg(r.body)}")
        val json = JSONObject(r.body)
        val cand = json.optJSONArray("candidates")?.optJSONObject(0)
            ?: throw Exception("Gemini gave no answer (${json.optJSONObject("promptFeedback")?.optString("blockReason") ?: "empty"})")
        val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: return Msg("assistant", "I have nothing to add.")
        val sb = StringBuilder()
        val calls = ArrayList<ToolCall>()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("functionCall")) {
                val fc = p.getJSONObject("functionCall")
                calls.add(ToolCall("g$i", fc.getString("name"), fc.optJSONObject("args") ?: JSONObject()))
            } else if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
        }
        return Msg("assistant", sb.toString(), calls)
    }

    // ------------------------------------------------------------------ OpenRouter (OpenAI-compatible)
    private fun userContent(m: Msg): Any {
        if (m.image == null) return m.text.ifBlank { " " }
        return JSONArray()
            .put(JSONObject().put("type", "text").put("text", m.text.ifBlank { " " }))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64," + m.image)))
    }

    private fun textProtocol(specs: List<Spec>): String {
        val sb = StringBuilder("You can control the phone and fetch live data with tools. To call a tool, output exactly: " +
                "<tool>{\"name\":\"TOOL_NAME\",\"args\":{...}}</tool> and nothing after it. Wait for the TOOL_RESULT message, then continue. " +
                "Call one tool at a time. Tools:\n")
        for (s in specs) sb.append("- ${s.name}(${s.params.joinToString(", ") { it.name + ":" + it.type }}): ${s.desc}\n")
        return sb.toString()
    }

    private fun buildOpenAI(system: String, msgs: List<Msg>, specs: List<Spec>, model: String, native: Boolean): JSONObject {
        val arr = JSONArray()
        val sys = if (!native && specs.isNotEmpty()) system + "\n\n" + textProtocol(specs) else system
        arr.put(JSONObject().put("role", "system").put("content", sys))
        for (m in msgs) when (m.role) {
            "user" -> arr.put(JSONObject().put("role", "user").put("content", userContent(m)))
            "assistant" -> {
                if (native && m.calls.isNotEmpty()) {
                    val tc = JSONArray()
                    for (c in m.calls) tc.put(JSONObject().put("id", c.id).put("type", "function")
                        .put("function", JSONObject().put("name", c.name).put("arguments", c.args.toString())))
                    arr.put(JSONObject().put("role", "assistant").put("content", m.text.ifBlank { " " }).put("tool_calls", tc))
                } else {
                    val t = m.text + m.calls.joinToString("") { "\n<tool>" + JSONObject().put("name", it.name).put("args", it.args) + "</tool>" }
                    arr.put(JSONObject().put("role", "assistant").put("content", t.ifBlank { " " }))
                }
            }
            "tool" -> if (native) {
                for ((c, r) in m.results) arr.put(JSONObject().put("role", "tool").put("tool_call_id", c.id).put("content", r))
            } else {
                arr.put(JSONObject().put("role", "user").put("content",
                    m.results.joinToString("\n") { "TOOL_RESULT ${it.first.name}: ${it.second}" }))
            }
        }
        val body = JSONObject().put("model", model).put("messages", arr).put("max_tokens", 1200)
        if (native && specs.isNotEmpty()) {
            val tools = JSONArray()
            for (s in specs) tools.put(JSONObject().put("type", "function").put("function", JSONObject()
                .put("name", s.name).put("description", s.desc)
                .put("parameters", JSONObject().put("type", "object").put("properties", props(s, false)).put("required", req(s)))))
            body.put("tools", tools)
        }
        return body
    }

    private fun openrouter(system: String, msgs: List<Msg>, specs: List<Spec>): Msg {
        val key = need("openrouter", "OpenRouter")
        val model = S.model("openrouter")
        val headers = mapOf("Content-Type" to "application/json", "Authorization" to "Bearer $key",
            "HTTP-Referer" to "https://github.com/jarvis-android", "X-Title" to "JARVIS")
        var native = specs.isNotEmpty() && model !in textToolModels
        var r = Net.http("POST", "https://openrouter.ai/api/v1/chat/completions", headers, buildOpenAI(system, msgs, specs, model, native).toString())
        if (r.code in listOf(400, 404, 422) && native) {
            // Model doesn't support native tool calling: switch to the text-tool protocol.
            textToolModels.add(model)
            native = false
            r = Net.http("POST", "https://openrouter.ai/api/v1/chat/completions", headers, buildOpenAI(system, msgs, specs, model, false).toString())
        }
        if (r.code !in 200..299) {
            val hint = when (r.code) {
                401 -> "Invalid OpenRouter key."
                402 -> "This model needs credits. Pick a :free model."
                429 -> "Rate limited. Free models throttle; wait a bit or pick another free model."
                else -> ""
            }
            throw Exception("OpenRouter ${r.code}: ${Net.errMsg(r.body)} $hint".trim())
        }
        val json = JSONObject(r.body)
        val message = json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?: throw Exception("OpenRouter returned no answer: ${Net.errMsg(r.body)}")
        var text = if (message.isNull("content")) "" else message.optString("content", "")
        val calls = ArrayList<ToolCall>()
        val tcs = message.optJSONArray("tool_calls")
        if (tcs != null) for (i in 0 until tcs.length()) {
            val t = tcs.getJSONObject(i)
            val f = t.getJSONObject("function")
            val args = try { JSONObject(f.optString("arguments", "{}").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
            calls.add(ToolCall(t.optString("id", "c$i"), f.getString("name"), args))
        }
        if (calls.isEmpty() && specs.isNotEmpty()) {
            val re = Regex("(?s)<tool>(.*?)</tool>")
            var i = 0
            for (m in re.findAll(text)) {
                try {
                    val o = JSONObject(m.groupValues[1].trim().removePrefix("```json").removeSuffix("```").trim())
                    calls.add(ToolCall("t${i++}", o.getString("name"), o.optJSONObject("args") ?: JSONObject()))
                } catch (e: Exception) { }
            }
            if (calls.isNotEmpty()) text = text.replace(re, "").trim()
        }
        return Msg("assistant", text, calls)
    }

    // ------------------------------------------------------------------ Claude
    private fun claude(system: String, msgs: List<Msg>, specs: List<Spec>): Msg {
        val key = need("claude", "Claude")
        val model = S.model("claude")
        val arr = JSONArray()
        for (m in msgs) when (m.role) {
            "user" -> {
                val blocks = JSONArray()
                if (m.image != null) blocks.put(JSONObject().put("type", "image").put("source",
                    JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", m.image)))
                blocks.put(JSONObject().put("type", "text").put("text", m.text.ifBlank { " " }))
                arr.put(JSONObject().put("role", "user").put("content", blocks))
            }
            "assistant" -> {
                val blocks = JSONArray()
                if (m.text.isNotBlank()) blocks.put(JSONObject().put("type", "text").put("text", m.text))
                for (c in m.calls) blocks.put(JSONObject().put("type", "tool_use").put("id", c.id).put("name", c.name).put("input", c.args))
                if (blocks.length() == 0) blocks.put(JSONObject().put("type", "text").put("text", " "))
                arr.put(JSONObject().put("role", "assistant").put("content", blocks))
            }
            "tool" -> {
                val blocks = JSONArray()
                for ((c, r) in m.results) blocks.put(JSONObject().put("type", "tool_result").put("tool_use_id", c.id).put("content", r))
                arr.put(JSONObject().put("role", "user").put("content", blocks))
            }
        }
        val body = JSONObject().put("model", model).put("max_tokens", 1200).put("system", system).put("messages", arr)
        if (specs.isNotEmpty()) {
            val tools = JSONArray()
            for (s in specs) tools.put(JSONObject().put("name", s.name).put("description", s.desc)
                .put("input_schema", JSONObject().put("type", "object").put("properties", props(s, false)).put("required", req(s))))
            body.put("tools", tools)
        }
        val r = Net.http("POST", "https://api.anthropic.com/v1/messages",
            mapOf("Content-Type" to "application/json", "x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
        if (r.code !in 200..299) throw Exception("Claude ${r.code}: ${Net.errMsg(r.body)}")
        val content = JSONObject(r.body).getJSONArray("content")
        val sb = StringBuilder()
        val calls = ArrayList<ToolCall>()
        for (i in 0 until content.length()) {
            val b = content.getJSONObject(i)
            when (b.optString("type")) {
                "text" -> sb.append(b.getString("text"))
                "tool_use" -> calls.add(ToolCall(b.getString("id"), b.getString("name"), b.optJSONObject("input") ?: JSONObject()))
            }
        }
        return Msg("assistant", sb.toString(), calls)
    }
}

class RunCtx(
    val background: Boolean = false,
    val cancelled: () -> Boolean = { false },
    val onStep: (String) -> Unit = {}
)

/** The agent loop: model -> tools -> model, until it has a spoken answer. */
object Agent {
    fun system(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm (zzz)", Locale.US).format(Date())
        val sb = StringBuilder()
        sb.append("You are JARVIS, the user's personal AI assistant living on their Android phone, inspired by Iron Man's JARVIS: witty, loyal, concise, highly capable.\n")
        sb.append("The user speaks English, Hindi or Hinglish. Reply in the language and style they used (Hindi in Devanagari if they wrote Devanagari; Hinglish in Roman letters if they mixed).\n")
        sb.append("Your replies are spoken aloud: keep them to 1-3 short sentences, no markdown, no lists, no emojis, unless the user asks for detail. Address the user as 'sir' only occasionally.\n")
        sb.append("Current date and time: $now.\n")
        sb.append("Use tools to act on the phone and to get live information; never claim an action happened unless the tool result confirms it. If a tool says a permission is missing, tell the user which one and that it is in the Permissions tab.\n")
        sb.append("Messages: send_message only PREPARES a draft and shows the recipient and exact text for the user to confirm. Say it is ready for confirmation; never say it was sent. Never message anyone the user did not ask for.\n")
        sb.append("Follow-up words like 'open it', 'do that', 'search more' refer to what was just discussed.\n")
        sb.append("Use look_at_screen or read_screen only when the user asks about their screen. For long research or 'while I do something else' requests, use run_in_background.\n")
        sb.append("Remember facts with the remember tool only when the user asks you to.\n")
        if (S.memoryOn) {
            val mem = DB.memory.all()
            if (mem.isNotEmpty()) {
                sb.append("What you know about the user (their own memory, they can edit it):\n")
                mem.takeLast(40).forEach { sb.append("- ").append(it.optString("text")).append('\n') }
            }
        }
        return sb.toString()
    }

    fun run(convo: MutableList<Msg>, text: String, image: String? = null, ctx: RunCtx = RunCtx()): String {
        while (convo.size > 40) convo.removeAt(0)
        while (convo.isNotEmpty() && convo[0].role != "user") convo.removeAt(0)
        val mark = convo.size
        convo.add(Msg("user", text, image = image))
        try {
            val specs = Tools.specs(ctx.background)
            for (step in 0 until 8) {
                if (ctx.cancelled()) throw Exception("Cancelled")
                val r = AI.chat(system(), convo, specs)
                convo.add(r)
                if (r.calls.isEmpty()) {
                    if (image != null) convo[mark] = Msg("user", text) // don't keep big images in memory
                    return r.text.trim().ifBlank { "Done." }
                }
                val results = r.calls.map { c -> ctx.onStep(Tools.label(c)); c to Tools.run(c, ctx) }
                convo.add(Msg("tool", results = results))
            }
            return "That took too many steps. Tell me where to continue."
        } catch (e: Exception) {
            while (convo.size > mark) convo.removeAt(convo.size - 1)
            throw e
        }
    }
}
