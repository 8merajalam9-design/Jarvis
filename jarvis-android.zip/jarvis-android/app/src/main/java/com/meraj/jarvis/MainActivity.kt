package com.meraj.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream

class MainActivity : Activity() {
    companion object { const val REQ_PERM = 1; const val REQ_PROJ = 2; const val REQ_PICK = 3 }

    private lateinit var screens: List<Screen>
    private lateinit var content: FrameLayout
    private lateinit var banner: TextView
    private val tabViews = ArrayList<TextView>()
    private var cur = 0
    private var confirmDlg: AlertDialog? = null
    private var pickCb: ((Uri) -> Unit)? = null
    private val ticker = object : Runnable {
        override fun run() { updateBanner(); J.main.postDelayed(this, 700) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        J.act = this
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        Voice.init()
        Notifier.channels()
        buildUi()
        Bus.clear()
        Bus.sub { updateBanner(); screens[cur].refresh() }
        show(0)
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERM)
        if (S.key(S.provider).isBlank()) {
            Brain.addLine("jarvis", "Online. Open the AI tab and add your ${S.provider} API key to get started. OpenRouter has free models.")
            show(6)
        } else Brain.addLine("jarvis", "Online. Tap the orb and talk, or say Hey Jarvis if wake word is on.")
    }

    override fun onResume() {
        super.onResume()
        J.act = this
        J.main.post(ticker)
        Brain.startWake()
        Bus.emit()
    }

    override fun onPause() {
        super.onPause()
        J.main.removeCallbacks(ticker)
        Brain.stopWake()
        if (Brain.state == St.LISTENING) { Ears.cancel(); Brain.set(St.IDLE) }
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    override fun onDestroy() { if (J.act === this) J.act = null; super.onDestroy() }

    // ------------------------------------------------------------ UI shell
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.BG) }
        val title = label("J.A.R.V.I.S", 20f, C.CYAN, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.3f; setPadding(0, 14.dp(), 0, 2.dp()) }
        banner = label("", 12f, C.DIM).apply {
            gravity = Gravity.CENTER; setPadding(8.dp(), 2.dp(), 8.dp(), 4.dp())
            setOnClickListener { if (ScreenCap.active) ScreenCap.stop() }
        }
        content = FrameLayout(this)
        screens = listOf(CoreScreen(this), ChatScreen(this), VisionScreen(this), AutoScreen(this),
            AppsScreen(this), PermScreen(this), SettingsScreen(this), HistoryScreen(this))
        val names = listOf("CORE", "CHAT", "VISION", "AUTO", "APPS", "ACCESS", "AI", "DATA")
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        names.forEachIndexed { i, n ->
            val t = label(n, 12f, C.DIM, true).apply {
                gravity = Gravity.CENTER; setPadding(16.dp(), 12.dp(), 16.dp(), 12.dp()); letterSpacing = 0.1f
                setOnClickListener { show(i) }
            }
            tabViews.add(t); tabs.addView(t)
        }
        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; setBackgroundColor(C.PANEL); addView(tabs) }
        root.addView(title)
        root.addView(banner)
        root.addView(content, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(tabScroll)
        setContentView(root)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean) = (this as android.content.Context).label(t, size, color, bold)

    fun show(i: Int) {
        cur = i
        content.removeAllViews()
        content.addView(screens[i].root)
        tabViews.forEachIndexed { idx, t -> t.setTextColor(if (idx == i) C.CYAN else C.DIM) }
        screens[i].refresh()
    }

    private fun updateBanner() {
        val sb = SpannableStringBuilder()
        fun part(s: String, color: Int) {
            if (sb.isNotEmpty()) sb.append("   ")
            val st = sb.length; sb.append(s); sb.setSpan(ForegroundColorSpan(color), st, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (Ears.active || Brain.state == St.LISTENING) part("● MIC LIVE", C.RED)
        if (ScreenCap.active) part("● SCREEN SHARING (tap to stop)", C.RED)
        if (Brain.wakeLoop) part("◉ WAKE WORD ARMED", C.AMBER)
        if (Tasks.running() > 0) part("⚙ ${Tasks.running()} task(s) running", C.CYAN)
        banner.text = sb
        banner.visibility = if (sb.isEmpty()) View.GONE else View.VISIBLE
        if (Brain.wakeLoop) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ------------------------------------------------------------ confirmations
    fun showConfirm(p: Pending) {
        confirmDlg?.dismiss()
        confirmDlg = AlertDialog.Builder(this)
            .setTitle("Send ${if (p.channel == "sms") "SMS" else "WhatsApp message"}?")
            .setMessage("To: ${p.name}\n${p.number}\n\n“${p.message}”\n\nTap a button, or say “yes” / “no”.")
            .setPositiveButton("Send") { _, _ -> Thread { Brain.announce(Confirm.accept()) }.start() }
            .setNegativeButton("Cancel") { _, _ -> Confirm.cancel(); Brain.announce("Cancelled. Nothing was sent.") }
            .setCancelable(false).show()
    }

    fun dismissConfirm() { J.main.post { confirmDlg?.dismiss(); confirmDlg = null } }

    // ------------------------------------------------------------ screen sharing
    fun requestProjection() {
        if (ScreenCap.active) { Toast.makeText(this, "Already sharing", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this)
            .setTitle("Start JARVIS Vision?")
            .setMessage("Android will ask you to confirm screen capture. While sharing, a notification and a red banner stay visible. Frames are kept in memory only and are sent to your AI provider (${S.provider}) only when you ask a question about your screen. You can stop at any time.")
            .setPositiveButton("Continue") { _, _ ->
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ------------------------------------------------------------ files
    fun pick(mime: String, cb: (Uri) -> Unit) {
        pickCb = cb
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType(mime).addCategory(Intent.CATEGORY_OPENABLE), REQ_PICK)
    }

    fun analyzeFile(uri: Uri) {
        show(1)
        Brain.addLine("sys", "Reading the file…")
        Thread {
            try {
                val type = contentResolver.getType(uri) ?: ""
                when {
                    type.startsWith("image/") -> {
                        Brain.submit("I shared an image. Explain what it shows and read any text in it.", imageJpeg(uri), false)
                    }
                    type == "application/pdf" -> {
                        Brain.submit("I shared a PDF (first pages shown as an image). Summarize it and note anything important.", pdfJpeg(uri), false)
                    }
                    else -> {
                        val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText().take(30000) } ?: ""
                        if (text.isBlank()) Brain.addLine("sys", "I couldn't read text from that file.")
                        else Brain.submit("Summarize this document for me:\n\n$text", null, false)
                    }
                }
            } catch (e: Exception) { Brain.addLine("sys", "Couldn't open that file: ${e.message}") }
        }.start()
    }

    private fun jpeg(b: Bitmap): String { val o = ByteArrayOutputStream(); b.compress(Bitmap.CompressFormat.JPEG, 82, o); return Net.b64(o.toByteArray()) }

    private fun imageJpeg(uri: Uri): String {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var sample = 1
        while (maxOf(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
        val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ?: throw Exception("unreadable image")
        return jpeg(bmp)
    }

    private fun pdfJpeg(uri: Uri): String {
        val pfd: ParcelFileDescriptor = contentResolver.openFileDescriptor(uri, "r") ?: throw Exception("unreadable pdf")
        PdfRenderer(pfd).use { r ->
            val n = minOf(3, r.pageCount)
            val pages = ArrayList<Bitmap>()
            for (i in 0 until n) {
                r.openPage(i).use { pg ->
                    val w = 900; val h = (900f * pg.height / pg.width).toInt()
                    val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    b.eraseColor(Color.WHITE)
                    pg.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    pages.add(b)
                }
            }
            val total = pages.sumOf { it.height }
            val out = Bitmap.createBitmap(900, total, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            var y = 0f
            for (b in pages) { cv.drawBitmap(b, 0f, y, null); y += b.height }
            return jpeg(out)
        }
    }

    // ------------------------------------------------------------ results
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PROJ && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, ScreenCaptureService::class.java).putExtra("code", resultCode).putExtra("data", data))
            show(2)
        } else if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            data?.data?.let { pickCb?.invoke(it) }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Bus.emit()
        if (permissions.contains(Manifest.permission.RECORD_AUDIO) && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) Brain.startWake()
    }
}
