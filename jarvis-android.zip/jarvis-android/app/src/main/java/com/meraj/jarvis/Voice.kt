package com.meraj.jarvis

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

object Voice {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var done: (() -> Unit)? = null
    @Volatile var speaking = false

    fun init() {
        if (tts != null) return
        tts = TextToSpeech(J.app) { st ->
            ready = st == TextToSpeech.SUCCESS
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { if (id == "last") finish() }
                @Deprecated("Deprecated in Java") override fun onError(id: String?) { finish() }
            })
        }
    }

    private fun finish() { speaking = false; val d = done; done = null; d?.invoke() }

    fun speak(text: String, onDone: () -> Unit) {
        val t = tts
        if (!ready || t == null) { onDone(); return }
        val clean = text.replace(Regex("[*_`#>~]"), "").replace(Regex("https?://\\S+"), "link").trim()
        if (clean.isEmpty()) { onDone(); return }
        val hindi = clean.any { it in '\u0900'..'\u097F' }
        val loc = when {
            hindi -> Locale("hi", "IN")
            S.speechLang == "en-IN" -> Locale("en", "IN")
            else -> Locale.getDefault()
        }
        val r = t.setLanguage(loc)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.US)
        t.setSpeechRate(S.ttsSpeed)
        t.setPitch(S.ttsPitch)
        done = onDone
        speaking = true
        val chunks = clean.chunked(3500)
        chunks.forEachIndexed { i, c ->
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, if (i == chunks.size - 1) "last" else "part$i")
        }
    }

    fun stop() { done = null; speaking = false; try { tts?.stop() } catch (e: Exception) { } }
}

object Ears {
    private var rec: SpeechRecognizer? = null
    @Volatile var level = 0f
    @Volatile var active = false

    fun listen(onPartial: (String) -> Unit, onResult: (String) -> Unit, onError: (Int) -> Unit) {
        J.main.post {
            try { rec?.destroy() } catch (e: Exception) { }
            if (!SpeechRecognizer.isRecognitionAvailable(J.app)) { active = false; onError(-1); return@post }
            val r = SpeechRecognizer.createSpeechRecognizer(J.app)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    active = false; level = 0f
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t.isNullOrBlank()) onError(SpeechRecognizer.ERROR_NO_MATCH) else onResult(t)
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(onPartial)
                }
                override fun onError(error: Int) { active = false; level = 0f; onError(error) }
                override fun onRmsChanged(rms: Float) { level = ((rms + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onReadyForSpeech(p: Bundle?) { active = true }
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, J.app.packageName)
            if (S.speechLang != "system") i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, S.speechLang)
            active = true
            r.startListening(i)
        }
    }

    fun stop() { J.main.post { try { rec?.stopListening() } catch (e: Exception) { } } }

    fun cancel() {
        J.main.post {
            try { rec?.cancel(); rec?.destroy() } catch (e: Exception) { }
            rec = null; active = false; level = 0f
        }
    }
}

enum class St { IDLE, LISTENING, THINKING, SPEAKING }
class Line(val role: String, val text: String)

/** Conversation controller: voice in, agent, voice out, wake word, hands-free. */
object Brain {
    @Volatile var state = St.IDLE
    @Volatile var partial = ""
    @Volatile var wakeLoop = false
    @Volatile private var runId = 0
    val lines = CopyOnWriteArrayList<Line>()
    val convo = mutableListOf<Msg>()

    private val wakeRe = Regex("(hey |hi |ok |okay |हे |अरे )?(jarvis|jarwis|jarvish|जार्विस|जारविस|जर्विस|जारवी?स)", RegexOption.IGNORE_CASE)
    private val yesRe = Regex("^(yes|yeah|yep|yup|sure|confirm|confirmed|send|send it|ok|okay|do it|go ahead|haan|haa|han|ha|हाँ|हां|भेज दो|भेजो|कर दो)\\b", RegexOption.IGNORE_CASE)
    private val noRe = Regex("^(no|nope|cancel|stop|don't|dont|nahi|nahin|mat|नहीं|रुको|मत)\\b", RegexOption.IGNORE_CASE)

    fun set(s: St) { state = s; Bus.emit() }

    fun addLine(role: String, text: String) {
        lines.add(Line(role, text))
        while (lines.size > 200) lines.removeAt(0)
        Bus.emit()
    }

    fun tapOrb() {
        when (state) {
            St.IDLE -> { stopWake(); listen() }
            St.LISTENING -> Ears.stop()
            St.SPEAKING -> { Voice.stop(); set(St.IDLE); resumeWake() }
            St.THINKING -> { runId++; set(St.IDLE); resumeWake() }
        }
    }

    fun listen() {
        if (state == St.THINKING) return
        Voice.stop()
        partial = ""
        set(St.LISTENING)
        Ears.listen(
            { partial = it; Bus.emit() },
            { text -> partial = ""; submit(text) },
            { err ->
                partial = ""; set(St.IDLE)
                if (err == android.speech.SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)
                    addLine("sys", "Microphone permission is off. Enable it in the Permissions tab.")
                resumeWake()
            }
        )
    }

    // ----------------------------------------------------------- wake word (only while the app is open and enabled)
    fun startWake() {
        if (!S.wakeWord || J.app.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        if (wakeLoop) return
        wakeLoop = true
        Bus.emit()
        wakeListen()
    }

    fun stopWake() {
        if (!wakeLoop) return
        wakeLoop = false
        if (state == St.IDLE) Ears.cancel()
        Bus.emit()
    }

    private fun resumeWake() { if (wakeLoop && state == St.IDLE) J.main.postDelayed({ wakeListen() }, 500) }

    private fun wakeListen() {
        if (!wakeLoop || state != St.IDLE) return
        Ears.listen({}, { text ->
            val m = wakeRe.find(text)
            if (m == null) resumeWake()
            else {
                val cmd = text.substring(m.range.last + 1).trim().trimStart(',', '.', '!', ' ')
                if (cmd.length >= 2) submit(cmd)
                else { set(St.SPEAKING); Voice.speak("Yes?") { set(St.IDLE); listen() } }
            }
        }, { resumeWake() })
    }

    // ----------------------------------------------------------- turns
    private fun voiceConfirm(t: String): Boolean {
        if (Confirm.pending == null) return false
        if (yesRe.containsMatchIn(t.trim())) {
            J.act?.dismissConfirm()
            Thread { announce(Confirm.accept()) }.start()
            return true
        }
        if (noRe.containsMatchIn(t.trim())) {
            J.act?.dismissConfirm()
            Confirm.cancel(); announce("Cancelled. Nothing was sent."); return true
        }
        return false
    }

    fun submit(text: String, image: String? = null, speak: Boolean = true) {
        val t = text.trim()
        if (t.isEmpty()) return
        addLine("user", t)
        if (voiceConfirm(t)) return
        if (state == St.THINKING) { addLine("sys", "Still working on the previous request."); return }
        set(St.THINKING)
        val id = ++runId
        Thread {
            val reply = try {
                Agent.run(convo, t, image, RunCtx(cancelled = { id != runId }))
            } catch (e: Exception) { "Sorry, ${e.message ?: "something went wrong"}" }
            if (id != runId) return@Thread
            DB.history.add(JSONObject().put("role", "user").put("text", t))
            DB.history.add(JSONObject().put("role", "jarvis").put("text", reply))
            addLine("jarvis", reply)
            speakThenContinue(reply, speak)
        }.start()
    }

    private fun speakThenContinue(reply: String, speak: Boolean) {
        if (S.speakReplies && speak) {
            set(St.SPEAKING)
            Voice.speak(reply) { set(St.IDLE); afterTurn() }
        } else { set(St.IDLE); afterTurn() }
    }

    private fun afterTurn() {
        if (S.handsFree && J.act != null) J.main.postDelayed({ if (state == St.IDLE) listen() }, 300) else resumeWake()
    }

    /** Spoken/logged message not caused by a user turn (confirmation results, finished tasks). */
    fun announce(text: String) {
        addLine("jarvis", text)
        if (state == St.IDLE && J.act != null) speakThenContinue(text, true)
    }
}
