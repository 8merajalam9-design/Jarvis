package com.meraj.jarvis

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

object C {
    val CYAN = Color.parseColor("#00E5FF")
    val BLUE = Color.parseColor("#2979FF")
    val BG = Color.parseColor("#050B14")
    val PANEL = Color.parseColor("#0B1A2B")
    val TEXT = Color.parseColor("#E6F6FF")
    val DIM = Color.parseColor("#7FA3BF")
    val RED = Color.parseColor("#FF5470")
    val GREEN = Color.parseColor("#4DFFB5")
    val AMBER = Color.parseColor("#FFC857")
}

fun Int.dp(): Int = (this * J.app.resources.displayMetrics.density).toInt()

fun rounded(fill: Int, stroke: Int, r: Int = 14, sw: Int = 1): GradientDrawable = GradientDrawable().apply {
    setColor(fill); cornerRadius = r.dp().toFloat(); setStroke(sw.dp().coerceAtLeast(1), stroke)
}

fun Context.label(t: String, size: Float = 14f, color: Int = C.TEXT, bold: Boolean = false): TextView = TextView(this).apply {
    text = t; textSize = size; setTextColor(color)
    if (bold) setTypeface(typeface, Typeface.BOLD)
}

fun Context.btn(t: String, color: Int = C.CYAN, onClick: () -> Unit): Button = Button(this).apply {
    text = t; isAllCaps = false; textSize = 13f; setTextColor(color)
    background = rounded(Color.argb(30, Color.red(color), Color.green(color), Color.blue(color)), color)
    minHeight = 0; minimumHeight = 40.dp(); minWidth = 0; minimumWidth = 0
    setPadding(14.dp(), 4.dp(), 14.dp(), 4.dp())
    setOnClickListener { onClick() }
}

fun Context.vbox(pad: Int = 0): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad.dp(), pad.dp(), pad.dp(), pad.dp()) }
fun Context.hbox(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }

fun Context.card(): LinearLayout = vbox(12).apply { background = rounded(C.PANEL, Color.parseColor("#17405C")) }

fun Context.field(hint: String, secret: Boolean = false): EditText = EditText(this).apply {
    this.hint = hint; setHintTextColor(C.DIM); setTextColor(C.TEXT); textSize = 14f
    background = rounded(Color.parseColor("#08121F"), Color.parseColor("#17405C"), 10)
    setPadding(12.dp(), 10.dp(), 12.dp(), 10.dp())
    if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else setSingleLine(false)
}

fun Context.sw(t: String, on: Boolean, change: (Boolean) -> Unit): Switch = Switch(this).apply {
    text = t; setTextColor(C.TEXT); isChecked = on; textSize = 14f
    setOnCheckedChangeListener { _, v -> change(v) }
}

fun Context.scroll(content: View): ScrollView = ScrollView(this).apply { isFillViewport = true; addView(content) }

fun LinearLayout.add(v: View, top: Int = 0, w: Int = ViewGroup.LayoutParams.MATCH_PARENT, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f): View {
    addView(v, LinearLayout.LayoutParams(w, h, weight).apply { topMargin = top.dp() })
    return v
}

fun LinearLayout.header(t: String) { add(context.label(t, 13f, C.CYAN, true).apply { letterSpacing = 0.15f }, 14) }

abstract class Screen(val ctx: Context) {
    val root: View by lazy { build() }
    abstract fun build(): View
    open fun refresh() {}
}

/** The animated circular AI core with a radial voice waveform. */
class OrbView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = RectF()
    private var t = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    private var smooth = 0f

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = minOf(width, height) * 0.20f
        val st = Brain.state
        val color = when (st) {
            St.IDLE -> C.CYAN; St.LISTENING -> C.RED; St.THINKING -> C.AMBER; St.SPEAKING -> C.GREEN
        }
        val target = when (st) {
            St.LISTENING -> Ears.level
            St.SPEAKING -> 0.5f + 0.4f * sin(t * 2 * PI * 3).toFloat()
            St.THINKING -> 0.15f
            St.IDLE -> if (Ears.active) Ears.level * 0.5f else 0.05f
        }
        smooth += (target - smooth) * 0.2f
        val wave = sin(t * 2 * PI).toFloat()
        val r = base * (1f + 0.04f * wave + 0.12f * smooth)

        p.style = Paint.Style.FILL
        for (i in 4 downTo 1) { p.color = color; p.alpha = 18; c.drawCircle(cx, cy, r + i * base * 0.18f, p) }
        p.color = color; p.alpha = 150; c.drawCircle(cx, cy, r, p)
        p.color = C.BG; p.alpha = 255; c.drawCircle(cx, cy, r * 0.62f, p)
        p.color = color; p.alpha = 220; c.drawCircle(cx, cy, r * 0.34f, p)

        // radial waveform bars
        p.style = Paint.Style.STROKE; p.strokeCap = Paint.Cap.ROUND; p.strokeWidth = 4.dp().toFloat() / 2f
        p.color = color
        val n = 56
        for (i in 0 until n) {
            val a = i * 2 * PI / n
            val v = 0.25f + 0.75f * (0.5f + 0.5f * sin(a * 5 + t * 2 * PI * 2).toFloat())
            val len = base * (0.08f + 0.55f * smooth * v)
            val r0 = r * 1.28f
            p.alpha = 90 + (150 * v).toInt()
            c.drawLine(cx + cos(a).toFloat() * r0, cy + sin(a).toFloat() * r0,
                cx + cos(a).toFloat() * (r0 + len), cy + sin(a).toFloat() * (r0 + len), p)
        }
        // rotating HUD rings
        p.strokeWidth = 2.dp().toFloat(); p.alpha = 160
        val rr = r * 1.28f + base * 0.9f
        arc.set(cx - rr, cy - rr, cx + rr, cy + rr)
        val spin = if (st == St.THINKING) 720f else 120f
        c.drawArc(arc, t * spin, 70f, false, p)
        c.drawArc(arc, t * spin + 180f, 40f, false, p)
        val r3 = rr + base * 0.2f
        arc.set(cx - r3, cy - r3, cx + r3, cy + r3)
        p.alpha = 90
        c.drawArc(arc, -t * spin * 0.6f, 100f, false, p)
    }
}
