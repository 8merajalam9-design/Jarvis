package com.meraj.jarvis

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import org.json.JSONObject

object Notifier {
    const val CH_STATUS = "status"
    const val CH_TASKS = "tasks"
    const val CH_REM = "reminders"

    fun channels() {
        val nm = J.app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "JARVIS active sessions", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_TASKS, "Background tasks", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel(CH_REM, "Reminders", NotificationManager.IMPORTANCE_HIGH))
    }

    fun post(channel: String, id: Int, title: String, text: String) {
        try {
            channels()
            val open = PendingIntent.getActivity(J.app, 0, Intent(J.app, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(J.app, channel).setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title).setContentText(text.take(200)).setStyle(Notification.BigTextStyle().bigText(text.take(1500)))
                .setContentIntent(open).setAutoCancel(true).build()
            J.app.getSystemService(NotificationManager::class.java).notify(id, n)
        } catch (e: Exception) { }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Notifier.post(Notifier.CH_REM, (System.currentTimeMillis() % 100000).toInt(), "JARVIS reminder", i.getStringExtra("text") ?: "Reminder")
    }
}

// ---------------------------------------------------------------------- Accessibility (explicit user activation)
class JarvisAccessibility : AccessibilityService() {
    companion object {
        @Volatile var instance: JarvisAccessibility? = null

        fun act(name: String): String {
            val s = instance ?: run {
                try { J.app.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
                return "The Accessibility service is off. I opened the page; the user must enable JARVIS there."
            }
            return when (name.lowercase().trim()) {
                "back" -> { s.performGlobalAction(GLOBAL_ACTION_BACK); "Went back." }
                "home" -> { s.performGlobalAction(GLOBAL_ACTION_HOME); "Went home." }
                "recents" -> { s.performGlobalAction(GLOBAL_ACTION_RECENTS); "Opened recent apps." }
                "notifications" -> { s.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS); "Opened notifications." }
                "quick_settings" -> { s.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS); "Opened quick settings." }
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) { s.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT); "Screenshot taken." } else "Screenshots need Android 9 or newer."
                "close_app" -> { s.performGlobalAction(GLOBAL_ACTION_HOME); "Sent the app to the background. Android doesn't let assistants force-close other apps; you can swipe it away in recents." }
                else -> "Unknown action."
            }
        }
    }

    override fun onServiceConnected() { instance = this; Bus.emit() }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; Bus.emit(); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun screenText(): String {
        val root = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 8000) return
            if (!n.isPassword && n.isVisibleToUser) {
                val t = n.text ?: n.contentDescription
                if (!t.isNullOrBlank()) sb.append(t).append('\n')
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return sb.toString()
    }
}

// ---------------------------------------------------------------------- Notification access (explicit user activation)
class JarvisNotificationListener : NotificationListenerService() {
    companion object { val recent = CopyOnWriteArrayList<String>() }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing) return
        val e = sbn.notification.extras
        val title = e.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
        val text = e.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        if (title.isBlank() && text.isBlank()) return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (ex: Exception) { sbn.packageName }
        recent.add(0, "$label: $title - $text")
        while (recent.size > 30) recent.removeAt(recent.size - 1)
    }

    override fun onListenerDisconnected() { recent.clear() }
}

// ---------------------------------------------------------------------- JARVIS VISION (MediaProjection)
object ScreenCap {
    @Volatile var active = false
    @Volatile var frame: Bitmap? = null

    fun stop() {
        J.app.startService(Intent(J.app, ScreenCaptureService::class.java).setAction("STOP"))
    }

    /** Returns the latest frame as a base64 JPEG, only while a session the user started is running. */
    fun grab(): String? {
        if (!active) return null
        var tries = 0
        while (frame == null && tries++ < 25) Thread.sleep(100)
        val bmp = frame ?: return null
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return Net.b64(out.toByteArray())
    }
}

object Vision {
    fun analyze(question: String): String {
        val img = ScreenCap.grab()
        if (img == null) {
            val svc = JarvisAccessibility.instance
            return if (svc != null) "Screen sharing is off, but here is the visible text:\n" + svc.screenText().take(5000)
            else "JARVIS Vision is not sharing the screen. Ask the user to start screen sharing in the Vision tab."
        }
        return AI.once(
            "You are JARVIS Vision. Describe and answer questions about the user's phone screenshot accurately. Read text exactly when asked. Be concise.",
            question, img
        )
    }
}

class ScreenCaptureService : Service() {
    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var last = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null || i.action == "STOP") { cleanup(); stopSelf(); return START_NOT_STICKY }
        Notifier.channels()
        val stop = PendingIntent.getService(this, 1, Intent(this, ScreenCaptureService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, Notifier.CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("JARVIS Vision is sharing your screen")
            .setContentText("Frames are analyzed only when you ask. Tap Stop to end.")
            .setOngoing(true).setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "Stop sharing", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(77, n)

        val code = i.getIntExtra("code", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION") val data: Intent? = i.getParcelableExtra("data")
        if (data == null) { cleanup(); stopSelf(); return START_NOT_STICKY }
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            proj = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { cleanup(); stopSelf() }
            }, Handler(mainLooper))
            val dm = resources.displayMetrics
            val scale = minOf(1f, 1280f / maxOf(dm.widthPixels, dm.heightPixels))
            val w = (dm.widthPixels * scale).toInt()
            val h = (dm.heightPixels * scale).toInt()
            val ht = HandlerThread("jarvis-vision").also { it.start() }
            thread = ht
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            vd = p.createVirtualDisplay("jarvis-vision", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            r.setOnImageAvailableListener({ rd ->
                val img = rd.acquireLatestImage()
                if (img != null) {
                    try {
                        val now = System.currentTimeMillis()
                        if (now - last > 700) {
                            last = now
                            val pl = img.planes[0]
                            val pad = pl.rowStride - pl.pixelStride * img.width
                            val bmp = Bitmap.createBitmap(img.width + pad / pl.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                            bmp.copyPixelsFromBuffer(pl.buffer)
                            ScreenCap.frame = Bitmap.createBitmap(bmp, 0, 0, img.width, img.height)
                            bmp.recycle()
                        }
                    } finally { img.close() }
                }
            }, Handler(ht.looper))
            ScreenCap.active = true
            Bus.emit()
        } catch (e: Exception) { cleanup(); stopSelf() }
        return START_NOT_STICKY
    }

    private fun cleanup() {
        ScreenCap.active = false
        ScreenCap.frame = null
        try { vd?.release() } catch (e: Exception) { }
        try { reader?.close() } catch (e: Exception) { }
        try { proj?.stop() } catch (e: Exception) { }
        try { thread?.quitSafely() } catch (e: Exception) { }
        vd = null; reader = null; proj = null; thread = null
        Bus.emit()
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }
}

// ---------------------------------------------------------------------- Background tasks
class BgTask(val id: Int, val title: String) {
    @Volatile var status = "running"
    @Volatile var step = "Starting"
    @Volatile var cancelled = false
    @Volatile var result = ""
}

object Tasks {
    val list = CopyOnWriteArrayList<BgTask>()
    private var counter = 0

    fun running() = list.count { it.status == "running" }

    fun start(description: String): BgTask {
        val t = BgTask(++counter, description.take(70))
        list.add(0, t)
        while (list.size > 12) list.removeAt(list.size - 1)
        try { J.app.startForegroundService(Intent(J.app, TaskService::class.java)) } catch (e: Exception) { }
        Bus.emit()
        Thread {
            try {
                val r = Agent.run(mutableListOf(), description, null,
                    RunCtx(background = true, cancelled = { t.cancelled }, onStep = { t.step = it; Bus.emit() }))
                if (!t.cancelled) { t.result = r; t.status = "done" }
            } catch (e: Exception) {
                t.status = if (t.cancelled) "cancelled" else "failed"
                t.result = e.message ?: ""
            }
            t.step = ""
            Bus.emit()
            if (t.status == "done") {
                Notifier.post(Notifier.CH_TASKS, 1000 + t.id, "JARVIS finished: ${t.title}", t.result)
                DB.history.add(JSONObject().put("role", "jarvis").put("text", "[Task ${t.id}] ${t.result}"))
                Brain.announce("Task finished. ${t.result.take(300)}")
            }
            if (running() == 0) try { J.app.stopService(Intent(J.app, TaskService::class.java)) } catch (e: Exception) { }
        }.start()
        return t
    }

    fun cancel(id: Int) { list.firstOrNull { it.id == id }?.let { it.cancelled = true; it.status = "cancelled" }; Bus.emit() }
}

class TaskService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        Notifier.channels()
        val n = Notification.Builder(this, Notifier.CH_STATUS).setSmallIcon(android.R.drawable.ic_popup_sync)
            .setContentTitle("JARVIS is working in the background").setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(78, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(78, n)
        return START_NOT_STICKY
    }
}
