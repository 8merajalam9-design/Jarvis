package com.meraj.jarvis

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Pending(val channel: String, val name: String, val number: String, val message: String)

/** Every outgoing message goes through here: shown to the user, sent only after confirmation. */
object Confirm {
    @Volatile var pending: Pending? = null

    fun request(p: Pending) {
        pending = p
        J.main.post { J.act?.showConfirm(p) }
        Bus.emit()
    }

    fun cancel() { pending = null; Bus.emit() }

    fun accept(): String {
        val p = pending ?: return "Nothing to confirm."
        pending = null
        Bus.emit()
        return try {
            if (p.channel == "sms") Tools.doSms(p) else Tools.doWhatsApp(p)
        } catch (e: Exception) { "Could not send: ${e.message}" }
    }
}

object Calc {
    private var s = ""
    private var i = 0
    fun eval(expr: String): Double {
        s = expr.replace(" ", "").replace("×", "*").replace("÷", "/").replace(",", "")
        i = 0
        val v = expr1()
        if (i < s.length) throw Exception("unexpected '${s[i]}'")
        return v
    }
    private fun expr1(): Double {
        var v = term()
        while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val t = term(); v = if (o == '+') v + t else v - t }
        return v
    }
    private fun term(): Double {
        var v = pow()
        while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
            val o = s[i++]; val t = pow()
            v = when (o) { '*' -> v * t; '/' -> v / t; else -> v % t }
        }
        return v
    }
    private fun pow(): Double {
        val b = unary()
        if (i < s.length && (s[i] == '^')) { i++; return Math.pow(b, pow()) }
        return b
    }
    private fun unary(): Double {
        if (i < s.length && s[i] == '-') { i++; return -unary() }
        if (i < s.length && s[i] == '+') { i++; return unary() }
        return atom()
    }
    private fun atom(): Double {
        if (i < s.length && s[i] == '(') { i++; val v = expr1(); if (i < s.length && s[i] == ')') i++; return v }
        val st = i
        while (i < s.length && (s[i].isLetter())) i++
        if (i > st) {
            val fn = s.substring(st, i)
            if (fn == "pi") return Math.PI
            if (fn == "e") return Math.E
            if (i < s.length && s[i] == '(') {
                i++; val a = expr1(); if (i < s.length && s[i] == ')') i++
                return when (fn) {
                    "sqrt" -> Math.sqrt(a); "sin" -> Math.sin(Math.toRadians(a)); "cos" -> Math.cos(Math.toRadians(a))
                    "tan" -> Math.tan(Math.toRadians(a)); "log" -> Math.log10(a); "ln" -> Math.log(a); "abs" -> Math.abs(a)
                    else -> throw Exception("unknown function $fn")
                }
            }
            throw Exception("unknown name $fn")
        }
        while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw Exception("number expected")
        return s.substring(st, i).toDouble()
    }
}

object Tools {
    private fun sp(name: String, desc: String, vararg p: P) = Spec(name, desc, p.toList())
    private fun str(n: String, d: String, req: Boolean = true) = P(n, "string", d, req)
    private fun int(n: String, d: String, req: Boolean = true) = P(n, "integer", d, req)
    private fun bool(n: String, d: String) = P(n, "boolean", d)

    private val all: List<Spec> = listOf(
        sp("open_app", "Open an installed app by name (e.g. YouTube, WhatsApp, Chrome).", str("name", "App name")),
        sp("list_apps", "Search installed apps by name.", str("query", "Search text", false)),
        sp("open_settings", "Open an Android settings screen. Pages: main, wifi, bluetooth, display, sound, battery, location, notifications, apps, accessibility, date, language, storage, nfc, airplane, hotspot, dnd. Bluetooth/Wi-Fi cannot be toggled silently by apps on modern Android, so this opens the right screen.", str("page", "Settings page")),
        sp("set_volume", "Change media volume. action is up, down, max, mute or set (set needs percent).", str("action", "up|down|max|mute|set"), int("percent", "0-100 for set", false)),
        sp("set_brightness", "Set screen brightness percent 1-100 (needs the Modify system settings permission).", int("percent", "1-100")),
        sp("flashlight", "Turn the flashlight on or off.", bool("on", "true=on")),
        sp("battery_status", "Battery percentage and charging state."),
        sp("connectivity_status", "Whether the phone is online and over Wi-Fi or mobile data."),
        sp("current_datetime", "Current date, time and time zone."),
        sp("open_camera", "Open the camera app."),
        sp("set_alarm", "Create an alarm at a time of day (24h).", int("hour", "0-23"), int("minute", "0-59"), str("label", "Alarm label", false)),
        sp("set_timer", "Start a countdown timer.", int("seconds", "Duration in seconds"), str("label", "Timer label", false)),
        sp("add_reminder", "Schedule a notification reminder N minutes from now.", str("text", "Reminder text"), int("minutes_from_now", "Minutes until the reminder")),
        sp("add_calendar_event", "Open the calendar with a new event prefilled (user taps Save). start is 'yyyy-MM-dd HH:mm' local time.", str("title", "Event title"), str("start", "yyyy-MM-dd HH:mm"), int("duration_minutes", "Length in minutes", false)),
        sp("web_search", "Search the internet for current information and get a summary with sources.", str("query", "Search query")),
        sp("read_webpage", "Fetch a web page and return its readable text (for summarizing).", str("url", "Full URL")),
        sp("open_url", "Open a web address in the browser.", str("url", "Full URL")),
        sp("youtube_search", "Open YouTube search results.", str("query", "Search text")),
        sp("navigate", "Start Google Maps navigation to a place.", str("destination", "Place or address")),
        sp("call_number", "Open the dialer with a number ready (the user presses call).", str("number", "Phone number")),
        sp("weather", "Current weather and 3-day forecast for a place (empty = current location by IP).", str("place", "City name", false)),
        sp("news", "Top news headlines, optionally about a topic.", str("topic", "Topic", false)),
        sp("calculate", "Evaluate a math expression exactly (+ - * / ^ % sqrt sin cos tan log ln).", str("expression", "Expression")),
        sp("internet_speed_test", "Measure download speed."),
        sp("find_contact", "Look up contacts by name (needs Contacts permission).", str("name", "Name")),
        sp("send_message", "Prepare a WhatsApp or SMS message. It is only SHOWN to the user for confirmation, never sent silently. 'to' is a contact name or phone number.", str("channel", "whatsapp or sms"), str("to", "Contact name or number"), str("message", "Exact message text")),
        sp("read_notifications", "Read the user's recent notifications (needs Notification access).", int("count", "How many (max 15)", false)),
        sp("remember", "Save a fact about the user to their memory (only when they ask).", str("fact", "Fact to remember")),
        sp("forget", "Delete remembered facts containing this text.", str("text", "Text to match")),
        sp("add_note", "Save a note or voice note.", str("text", "Note text")),
        sp("list_notes", "List saved notes."),
        sp("add_todo", "Add a to-do item.", str("text", "Task")),
        sp("list_todos", "List to-do items."),
        sp("complete_todo", "Mark a to-do done (by matching text).", str("text", "Text to match")),
        sp("read_clipboard", "Read the clipboard (only if the user enabled clipboard assist in AI settings)."),
        sp("copy_to_clipboard", "Copy text to the clipboard.", str("text", "Text")),
        sp("read_screen", "Read the visible text on the current screen via the Accessibility service (user must have enabled it).", ),
        sp("look_at_screen", "Look at the user's screen with AI vision and answer a question about it. Works only while JARVIS Vision screen sharing is on.", str("question", "What to find out")),
        sp("phone_action", "Press a system button via Accessibility: back, home, recents, screenshot, notifications, quick_settings, close_app (goes home; Android does not let apps force-close others).", str("action", "Action name")),
        sp("save_routine", "Save a custom automation routine the user can run later.", str("name", "Routine name"), str("instructions", "What it should do, step by step")),
        sp("run_routine", "Run a saved routine by name.", str("name", "Routine name")),
        sp("run_in_background", "Run a long task (research, comparisons, searches) in the background while the user keeps using the phone. Progress shows in the app and the result arrives as a notification.", str("task", "Full self-contained task description"))
    )

    fun specs(background: Boolean): List<Spec> = if (background) all.filter { it.name != "run_in_background" } else all

    fun label(c: ToolCall) = "Running ${c.name.replace('_', ' ')}"

    // ------------------------------------------------------------------ helpers
    private val ctx: Context get() = J.app

    private fun has(perm: String) = ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

    fun launchables(): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            .distinctBy { it.second }.sortedBy { it.first.lowercase() }
    }

    fun openApp(name: String): String {
        val want = name.trim().lowercase()
        val apps = launchables()
        val hit = apps.firstOrNull { it.first.lowercase() == want }
            ?: apps.firstOrNull { it.first.lowercase().startsWith(want) }
            ?: apps.firstOrNull { it.first.lowercase().contains(want) }
            ?: return "No installed app matches '$name'."
        launch(ctx.packageManager.getLaunchIntentForPackage(hit.second) ?: return "Cannot launch ${hit.first}.")
        return "Opened ${hit.first}."
    }

    fun settingsAction(page: String): String = when (page.lowercase().trim()) {
        "wifi", "wi-fi", "internet" -> Settings.ACTION_WIFI_SETTINGS
        "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
        "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
        "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
        "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
        "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        "notifications", "notification" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
        "apps", "app" -> Settings.ACTION_APPLICATION_SETTINGS
        "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
        "date", "time" -> Settings.ACTION_DATE_SETTINGS
        "language" -> Settings.ACTION_LOCALE_SETTINGS
        "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
        "nfc" -> Settings.ACTION_NFC_SETTINGS
        "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        "hotspot", "tethering" -> "android.settings.TETHER_SETTINGS"
        "dnd", "do not disturb" -> "android.settings.ZEN_MODE_SETTINGS"
        else -> Settings.ACTION_SETTINGS
    }

    fun openSettings(page: String): String {
        val a = settingsAction(page)
        val i = Intent(a)
        if (a == Settings.ACTION_APP_NOTIFICATION_SETTINGS) i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        return try { launch(i); "Opened $page settings." } catch (e: Exception) { launch(Intent(Settings.ACTION_SETTINGS)); "Opened settings." }
    }

    fun a11yEnabled(): Boolean = JarvisAccessibility.instance != null
    fun notifAccessEnabled(): Boolean =
        (Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: "").contains(ctx.packageName)

    fun digits(s: String) = s.filter { it.isDigit() }
    fun intlNumber(raw: String): String {
        val t = raw.trim()
        val d = digits(t)
        return when {
            t.startsWith("+") -> d
            d.length == 10 -> S.countryCode + d
            d.startsWith("0") -> S.countryCode + d.drop(1)
            else -> d
        }
    }

    class Contact(val name: String, val number: String)

    fun contacts(name: String): List<Contact> {
        val out = ArrayList<Contact>()
        val cur = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        ) ?: return out
        cur.use {
            while (it.moveToNext() && out.size < 12) {
                val c = Contact(it.getString(0) ?: "", it.getString(1) ?: "")
                if (out.none { o -> o.name == c.name && digits(o.number) == digits(c.number) }) out.add(c)
            }
        }
        return out
    }

    fun doSms(p: Pending): String {
        if (has(Manifest.permission.SEND_SMS)) {
            val sm: SmsManager = if (android.os.Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            sm.sendMultipartTextMessage(p.number, null, sm.divideMessage(p.message), null, null)
            return "SMS sent to ${p.name}."
        }
        launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${p.number}")).putExtra("sms_body", p.message))
        return "I opened your SMS app with the message ready for ${p.name}. Tap send there."
    }

    fun doWhatsApp(p: Pending): String {
        val uri = Uri.parse("https://wa.me/${intlNumber(p.number)}?text=${Uri.encode(p.message)}")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b", null)) {
            try {
                val i = Intent(Intent.ACTION_VIEW, uri)
                if (pkg != null) i.setPackage(pkg)
                launch(i)
                return "WhatsApp is open with your message to ${p.name}. Tap send there to finish; WhatsApp does not let apps send for you."
            } catch (e: ActivityNotFoundException) { }
        }
        return "WhatsApp isn't installed."
    }

    private fun toTime(s: String): Long = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(s.trim())?.time ?: throw Exception("bad time format")

    // ------------------------------------------------------------------ executor
    fun run(c: ToolCall, rc: RunCtx): String = try { exec(c, rc) } catch (e: Exception) { "Tool failed: ${e.message ?: e.javaClass.simpleName}" }

    private fun exec(c: ToolCall, rc: RunCtx): String {
        val a = c.args
        when (c.name) {
            "open_app" -> return openApp(a.getString("name"))
            "list_apps" -> {
                val q = a.optString("query").lowercase()
                return launchables().filter { it.first.lowercase().contains(q) }.take(25).joinToString(", ") { it.first }.ifBlank { "No matches." }
            }
            "open_settings" -> return openSettings(a.getString("page"))
            "set_volume" -> {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                when (a.getString("action").lowercase()) {
                    "up" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                    "down" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                    "max" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, max, AudioManager.FLAG_SHOW_UI)
                    "mute" -> am.setStreamVolume(AudioManager.STREAM_MUSIC, 0, AudioManager.FLAG_SHOW_UI)
                    else -> am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * a.optInt("percent", 50).coerceIn(0, 100)) / 100, AudioManager.FLAG_SHOW_UI)
                }
                return "Media volume now ${am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max}%."
            }
            "set_brightness" -> {
                if (!Settings.System.canWrite(ctx)) {
                    launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
                    return "I need the 'Modify system settings' permission. I opened the page; ask again after enabling it."
                }
                val pct = a.getInt("percent").coerceIn(1, 100)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, pct * 255 / 100)
                return "Brightness set to $pct%."
            }
            "flashlight" -> {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    ?: return "This phone has no flashlight."
                val on = a.getBoolean("on")
                cm.setTorchMode(id, on)
                return if (on) "Flashlight on." else "Flashlight off."
            }
            "battery_status" -> {
                val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
                val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                return "Battery ${lvl * 100 / scale}%, ${if (charging) "charging" else "not charging"}."
            }
            "connectivity_status" -> {
                val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
                val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Offline."
                val kind = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                    else -> "a network"
                }
                return if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) "Online via $kind." else "Connected to $kind but no internet access."
            }
            "current_datetime" -> return SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm:ss zzz", Locale.US).format(Date())
            "open_camera" -> { launch(Intent(MediaStore.ACTION_IMAGE_CAPTURE)); return "Camera opened." }
            "set_alarm" -> {
                launch(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "JARVIS"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return "Alarm set for %02d:%02d.".format(a.getInt("hour"), a.getInt("minute"))
            }
            "set_timer" -> {
                launch(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "JARVIS")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
                return "Timer started for ${a.getInt("seconds")} seconds."
            }
            "add_reminder" -> {
                val mins = a.getInt("minutes_from_now").coerceAtLeast(1)
                val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val i = Intent().setComponent(ComponentName(ctx, ReminderReceiver::class.java)).putExtra("text", a.getString("text"))
                val code = (System.currentTimeMillis() % 100000).toInt()
                val pi = PendingIntent.getBroadcast(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + mins * 60_000L, pi)
                return "Reminder set for $mins minutes from now (it is lost if the phone restarts)."
            }
            "add_calendar_event" -> {
                val start = toTime(a.getString("start"))
                val end = start + a.optInt("duration_minutes", 60) * 60_000L
                launch(Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, a.getString("title"))
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end))
                return "Calendar opened with the event; the user needs to tap Save."
            }
            "web_search" -> return Net.search(a.getString("query"))
            "read_webpage" -> return Net.readPage(a.getString("url"))
            "open_url" -> {
                var u = a.getString("url").trim()
                if (!u.startsWith("http")) u = "https://$u"
                launch(Intent(Intent.ACTION_VIEW, Uri.parse(u))); return "Opened $u."
            }
            "youtube_search" -> {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=${Net.enc(a.getString("query"))}")))
                return "Opened YouTube search."
            }
            "navigate" -> {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=${Net.enc(a.getString("destination"))}"))); return "Navigation started."
            }
            "call_number" -> { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(a.getString("number"))}"))); return "Dialer opened." }
            "weather" -> return Net.weather(a.optString("place"))
            "news" -> return Net.news(a.optString("topic"))
            "calculate" -> {
                val v = Calc.eval(a.getString("expression"))
                return if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else "%.8g".format(v)
            }
            "internet_speed_test" -> return Net.speedTest()
            "find_contact" -> {
                if (!has(Manifest.permission.READ_CONTACTS)) return "Contacts permission is off. Ask the user to grant it in the Permissions tab."
                val l = contacts(a.getString("name"))
                return if (l.isEmpty()) "No contact found." else l.joinToString("\n") { "${it.name}: ${it.number}" }
            }
            "send_message" -> {
                val channel = a.getString("channel").lowercase().let { if (it.contains("what")) "whatsapp" else "sms" }
                val to = a.getString("to").trim()
                val msg = a.getString("message")
                var name = to
                var number = to
                if (digits(to).length < 7) {
                    if (!has(Manifest.permission.READ_CONTACTS)) return "Contacts permission is off. Ask the user to grant it in the Permissions tab, or give a phone number."
                    val l = contacts(to)
                    if (l.isEmpty()) return "No contact named '$to'. Ask the user for the exact name or number."
                    val names = l.map { it.name }.distinct()
                    val exact = l.filter { it.name.equals(to, true) }
                    val pick = if (names.size == 1) l.first() else if (exact.map { it.name }.distinct().size == 1) exact.first()
                    else return "Several contacts match: ${names.joinToString(", ")}. Ask the user which one."
                    name = pick.name; number = pick.number
                }
                Confirm.request(Pending(channel, name, number, msg))
                return "Draft shown to the user for confirmation: $channel to $name ($number): \"$msg\". It has NOT been sent. Ask the user to confirm."
            }
            "read_notifications" -> {
                if (!notifAccessEnabled()) {
                    launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    return "Notification access is off. I opened the page; the user must enable JARVIS there."
                }
                val l = JarvisNotificationListener.recent.take(a.optInt("count", 8).coerceIn(1, 15))
                return if (l.isEmpty()) "No recent notifications." else l.joinToString("\n")
            }
            "remember" -> { DB.memory.add(JSONObject().put("text", a.getString("fact"))); Bus.emit(); return "Remembered." }
            "forget" -> {
                val t = a.getString("text").lowercase()
                val hit = DB.memory.all().filter { it.optString("text").lowercase().contains(t) }
                hit.forEach { DB.memory.remove(it.optLong("id")) }; Bus.emit()
                return "Forgot ${hit.size} item(s)."
            }
            "add_note" -> { DB.notes.add(JSONObject().put("text", a.getString("text"))); Bus.emit(); return "Note saved." }
            "list_notes" -> return DB.notes.all().takeLast(15).joinToString("\n") { "- " + it.optString("text") }.ifBlank { "No notes." }
            "add_todo" -> { DB.todos.add(JSONObject().put("text", a.getString("text")).put("done", false)); Bus.emit(); return "Added to your to-do list." }
            "list_todos" -> return DB.todos.all().joinToString("\n") { (if (it.optBoolean("done")) "[x] " else "[ ] ") + it.optString("text") }.ifBlank { "No to-dos." }
            "complete_todo" -> {
                val t = a.getString("text").lowercase()
                val hit = DB.todos.all().firstOrNull { it.optString("text").lowercase().contains(t) } ?: return "No matching to-do."
                DB.todos.update(hit.optLong("id")) { it.put("done", true) }; Bus.emit()
                return "Marked done: ${hit.optString("text")}"
            }
            "read_clipboard" -> {
                if (!S.clipboardOn) return "Clipboard assist is off. The user can enable it in the AI tab."
                return J.onMainWait {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()?.take(4000) ?: "Clipboard is empty."
                } ?: "Could not read clipboard."
            }
            "copy_to_clipboard" -> {
                J.onMain { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("JARVIS", a.getString("text"))) }
                return "Copied."
            }
            "read_screen" -> {
                val svc = JarvisAccessibility.instance ?: run {
                    launch(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    return "The Accessibility service is off. I opened the page; the user must enable JARVIS there."
                }
                return svc.screenText().ifBlank { "No readable text on screen." }
            }
            "look_at_screen" -> return Vision.analyze(a.optString("question", "What is on the screen?"))
            "phone_action" -> return JarvisAccessibility.act(a.getString("action"))
            "save_routine" -> {
                DB.routines.add(JSONObject().put("name", a.getString("name")).put("instructions", a.getString("instructions"))); Bus.emit()
                return "Routine '${a.getString("name")}' saved."
            }
            "run_routine" -> {
                val n = a.getString("name").lowercase()
                val r = DB.routines.all().firstOrNull { it.optString("name").lowercase().contains(n) } ?: return "No routine named '${a.getString("name")}'."
                return "Routine '${r.optString("name")}' instructions: ${r.optString("instructions")}. Carry them out now with your tools."
            }
            "run_in_background" -> {
                val t = Tasks.start(a.getString("task"))
                return "Background task #${t.id} started. The user will be notified with the result."
            }
        }
        return "Unknown tool ${c.name}."
    }
}
