package com.meraj.jarvis

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-GCM with a non-exportable Android Keystore key. API keys and local data are encrypted with it. */
object Secrets {
    private const val ALIAS = "jarvis_master_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    fun enc(s: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(s.toByteArray())
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    fun dec(s: String): String {
        val b = Base64.decode(s, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b, 0, 12))
        return String(c.doFinal(b, 12, b.size - 12))
    }
}

/** User settings. API keys are stored encrypted. */
object S {
    private val p by lazy { J.app.getSharedPreferences("settings", Context.MODE_PRIVATE) }
    private val sp by lazy { J.app.getSharedPreferences("secrets", Context.MODE_PRIVATE) }

    var provider: String
        get() = p.getString("provider", "gemini") ?: "gemini"
        set(v) { p.edit().putString("provider", v).apply() }

    fun defaultModel(prov: String) = when (prov) {
        "gemini" -> "gemini-2.5-flash"
        "openrouter" -> "openrouter/free"
        else -> "claude-haiku-5-5"
    }
    fun model(prov: String): String = p.getString("model_$prov", null)?.takeIf { it.isNotBlank() } ?: defaultModel(prov)
    fun setModel(prov: String, v: String) { p.edit().putString("model_$prov", v.trim()).apply() }

    fun key(prov: String): String = try { sp.getString("key_$prov", null)?.let { Secrets.dec(it) } ?: "" } catch (e: Exception) { "" }
    fun setKey(prov: String, v: String) {
        if (v.isBlank()) sp.edit().remove("key_$prov").apply() else sp.edit().putString("key_$prov", Secrets.enc(v.trim())).apply()
    }

    var ttsSpeed: Float get() = p.getFloat("speed", 1.0f); set(v) { p.edit().putFloat("speed", v).apply() }
    var ttsPitch: Float get() = p.getFloat("pitch", 0.9f); set(v) { p.edit().putFloat("pitch", v).apply() }
    var speechLang: String get() = p.getString("slang", "system") ?: "system"; set(v) { p.edit().putString("slang", v).apply() }
    var wakeWord: Boolean get() = p.getBoolean("wake", false); set(v) { p.edit().putBoolean("wake", v).apply() }
    var handsFree: Boolean get() = p.getBoolean("hands", false); set(v) { p.edit().putBoolean("hands", v).apply() }
    var speakReplies: Boolean get() = p.getBoolean("speak", true); set(v) { p.edit().putBoolean("speak", v).apply() }
    var memoryOn: Boolean get() = p.getBoolean("memory", true); set(v) { p.edit().putBoolean("memory", v).apply() }
    var clipboardOn: Boolean get() = p.getBoolean("clip", false); set(v) { p.edit().putBoolean("clip", v).apply() }
    var countryCode: String get() = p.getString("cc", "91") ?: "91"; set(v) { p.edit().putString("cc", v.filter { it.isDigit() }).apply() }
}

/** Small encrypted JSON-list store (history, memory, notes, to-dos, routines). */
class Store(private val name: String) {
    private val f get() = File(J.app.filesDir, "$name.dat")

    @Synchronized fun all(): List<JSONObject> {
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(Secrets.dec(f.readText()))
            (0 until a.length()).map { a.getJSONObject(it) }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized private fun write(l: List<JSONObject>) {
        f.writeText(Secrets.enc(JSONArray(l).toString()))
    }

    @Synchronized fun add(o: JSONObject, max: Int = 400): JSONObject {
        o.put("id", System.nanoTime()); o.put("time", System.currentTimeMillis())
        val l = all().toMutableList(); l.add(o)
        while (l.size > max) l.removeAt(0)
        write(l); return o
    }

    @Synchronized fun remove(id: Long) { write(all().filter { it.optLong("id") != id }) }
    @Synchronized fun update(id: Long, fn: (JSONObject) -> Unit) { val l = all(); l.forEach { if (it.optLong("id") == id) fn(it) }; write(l) }
    @Synchronized fun clear() { f.delete() }
}

object DB {
    val memory = Store("memory")
    val notes = Store("notes")
    val todos = Store("todos")
    val routines = Store("routines")
    val history = Store("history")
}
